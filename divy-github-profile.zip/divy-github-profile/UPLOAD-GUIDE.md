# Upload Guide

1. Create a **Public** GitHub repository named exactly:
   `devanshverma7499-eng`
2. Upload `README.md` and the complete `assets/` folder.
3. Commit the changes to the default branch.
4. Open:
   `https://github.com/devanshverma7499-eng`

The repository must be named exactly the same as the GitHub username for GitHub to treat it as the profile README repository.
